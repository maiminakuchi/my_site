<?php
function dbConnect(){
      $dsn='mysql:dbname=cafe;host=localhost;charset=utf8';
      $user='cafe';
      $pass='cafe';

      try {
      $dbh = new PDO($dsn,$user,$pass,[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,]);
      echo '接続成功';

       } catch (PDOException $e) {
       echo '接続失敗'.$e->getMessage();
       exit();
       };
       return $dbh;
      }


?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>削除しました
</title>
</head>
<body>
削除しました
<br/><br/>
<?php include("val.php"); ?>
<?php

       $dbh = dbConnect();
       $id = $_GET['id'];
       // $sql = "SELECT * FROM contacts Where id = ".$id;
       // $stmt = $dbh->query($sql);
       //③SQLの結果を受け取る
       // $result = $stmt->fetch(PDO::FETCH_ASSOC);
         // var_dump($result);


    $dbh = dbConnect();
       $delete = "DELETE FROM contacts WHERE id = ".$id;
       // var_dump($update);
       $stmt = $dbh->query($delete);
       $stmt->execute();
       header( "Location: contact.php" );



?>

<a href="contact.php">トップ画面に戻る</a>
</body>
</html>