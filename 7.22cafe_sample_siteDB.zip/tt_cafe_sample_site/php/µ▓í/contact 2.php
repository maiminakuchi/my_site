<?php
// session_start();

// $_SESSION['name']=$_POST;
// $_SESSION['kana']=$_POST;
// $_SESSION['phone']=$_POST;
// $_SESSION['mail']=$_POST;
// $_SESSION['body']=$_POST;
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>お問い合わせ
  </title>
  <link rel="stylesheet" type="text/css" href="../css/contact.css">
</head>
<body>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>


<?php include("header.php"); ?>
<?php include("val.php"); ?>
<?php
$name=$_POST['name'];
$kana=$_POST['kana'];
$phone=$_POST['phone'];
$email=$_POST['email'];
$body=$_POST['body'];
?>

<!-- ⭐️ -->

<section class="section2">
 <div class="contact-box">
   <h2 class="head">お問い合わせ</h2>
    <form method="post" action="confirm2.php" id="form1">
    <h3>下記の項目をご記入の上送信ボタンを押してください</h3>
    <p>送信頂いた件につきましては、当社より折り返しご連絡を差し上げます。</p>
    <p>なお、ご連絡までに、お時間を頂く場合もございますので予めご了承ください。</p>
    <p><span class="kome">*</span>は必須項目となります。</p>
    <dl>
      <dt><label for="name">氏名<span class="kome">*</span></label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if ($_POST){
       echo $err_msg[
        0
        // 'name'
      ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd>
      <input type="text" name="name" id="name" placeholder="海野守" value="<?php if($_POST){echo $name;} ?>">
      </dd>

      <dt><label for="kana">フリガナ<span class="kome">*</span></label></dt>

      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if($_POST){
       echo $err_msg[
        1
        // 'kana'
      ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="kana" id="kana" placeholder="ウミノマモル" value="<?php if($_POST){echo $kana;} ?>"></dd>

      <dt><label for="phone">電話番号</label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if($_POST){
       echo $err_msg[
        2
        // 'phone'
      ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="phone" id="phone" placeholder="09012345678" value="<?php if($_POST){echo $phone;} ?>"></dd>

      <dt><label for="email">メールアドレス<span class="kome">*</span></label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if($_POST){
       echo $err_msg[
        3
        // 'email'
      ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="email" id="email" placeholder="umino@test.co.jp" value="<?php if($_POST){echo $email;} ?>"></dd>
      <h3>お問い合わせ内容をご記入ください<span class="kome">*</span></h3>
        </dl>
        <dl>
          <!-- エラー表示 -->
          <dd class="err">
           <?php
           if($_POST){
           echo $err_msg[
            4
            // 'body'
          ];
           }
           ?>
          </dd>
          <!-- ここまで -->
          <dd><textarea name="body" id="body" value="<?php if($_POST){echo $body;} ?>"></textarea></dd>
          <dd id="submit1"><input class="submit" type="submit" value="送　信"></dd>
        </dl>

    </form>
 </div>

<?php
      $dsn='mysql:dbname=cafe;host=localhost;charset=utf8';
      $user='cafe';
      $pass='cafe';
      try {
      $dbh = new PDO($dsn,$user,$pass);
      $dbh->query('SET NAMES UTF-8');

      echo '接続成功';

// [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,]

        $sql = 'SELECT*FROM contacts WHERE 1';
        $stmt = $dbh->prepare($sql);
        $stmt->execute();

        while(1)
        {
          $rec = $stmt->fetch(PDO::FETCH_ASSOC);
          if($rec == false)
          {
            break;
          }
          echo $rec['id'];
          echo $rec['name'];
          echo $rec['kana'];
          echo $rec['phone'];
          echo $rec['email'];
          echo $rec['body'];
          echo '<br/>';
          }

          $dbh = null;
          //接続解除
        } catch (Exception $e) {

        echo '接続失敗';
        exit();
        }


      // echo '接続失敗'.$e->getMessage();
      // exit();
?>

<!-- jqueryバリデーション -->
    <script>
      $('#submit1').click(function(){
        var name = $('#name').val(); //value()を使ってvalue値(value=""の部分)を取得
        var kana = $('#kana').val();
        var phone = $('#phone').val();
        var email = $('#email').val();
        var body = $('#body').val();
        var err = 0;
        let msg = [];
        //氏名チェック
        if (name == "" || name.length > 10) {
          err += 1;
          msg.push('氏名は必須項目です。10文字以内でご入力ください。\n');
        }
        // フリガナチェック
        if (kana == "" || kana.length > 10) {
          err += 1;
          msg.push('フリガナは必須項目です。10文字以内でご入力ください。\n');
        }
        // 電話番号チェック
        if ( phone !== "" && !phone.match(/^[0-9]+$/)) {
          err += 1;
          msg.push('電話番号は0-9の数字のみでご入力ください。\n');
        }
        // メールアドレスチェック
        // 先頭の1文字/＠まで/＠/ドメインまで/ドメイン
        if (!email.match(/^[A-Za-z0-9]{1}[A-Za-z0-9_.-]*@{1}[A-Za-z0-9_.-]{1,}\.[A-Za-z0-9]{1,}$/)||email=="") {
          err += 1;
          msg.push(
  'メールアドレスは必須です。メールアドレスは正しくご入力ください。\n');
        }
        //お問い合わせ内容チェック
        if (body == "") {
          err += 1;
          msg.push('お問い合わせ内容は必須入力です。\n');
        }
        // チェックに引っかかっていたら遷移しない
        if (err > 0){
          $('form').submit(function() {
          $(this).attr('action', 'contact.php');
          alert(msg);
          });
        }
        //ブラウザ側が標準で用意しているイベントを中断できる
        // if (err > 0){
        //   return false;
        // }
      });
    </script>
</section>



<!-- ⭐️ -->
<section class="hooter">
 <div class="outer">
  <div class="info">
   <div class="inner">
   	<h2>企業情報</h2>
   	 <ul>
      <li><a href="#">ご利用方法</a></li>
      <li><a href="#">ニュースルーム</a></li>
      <li><a href="#">株主・投資家のみなさまへ</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">採用情報</a></li>
     </ul>
    </div>
    <div class="inner">
      	<h2>コミュニティ</h2>
   	 <ul>
      <li><a href="#">ダイバーシティ</a></li>
      <li><a href="#">アクセシビリティ対応</a></li>
      <li><a href="#">お友達を招待</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>ホスト</h2>
   	 <ul>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>サポート</h2>
   	 <ul>
      <li><a href="#">新型コロナウイルスに対する取り組み</a></li>
      <li><a href="#">ヘルプセンター</a></li>
      <li><a href="#">キャンセルオプション</a></li>
      <li><a href="#">コミュニティサポート</a></li>
      <li><a href="#">信頼＆安全</a></li>
     </ul>
   </div>
  </div>
  <div class="policy">
  	<p>このサイトの素材は全て著作権フリーのものを使用しています。</p>
  	<div class="hooterlink">
  	 <a href="">プライバシーポリシー  </a>
  	 <a href="">利用規約  </a>
  	 <a href="">サイトマップ  </a>
  	 <a href="">企業情報  </a>
  	</div>
  	<div class="copy">© 2021- LiNew, Inc. All rights reserved.</div>
  </div>
 </div>
</section>


<p id="page-top"><a href="#wrap">Jump To Top</a></p>
<script>
$(function() {
    var showFlag = false;
    var topBtn = $('#page-top');
    topBtn.css('bottom', '-100px');
    var showFlag = false;
    //スクロールが100に達したらボタン表示
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            if (showFlag == false) {
                showFlag = true;
                topBtn.stop().animate({'bottom' : '0px'}, 200);
            }
        } else {
            if (showFlag) {
                showFlag = false;
                topBtn.stop().animate({'bottom' : '-100px'}, 200);
            }
        }
    });
    //スクロールしてトップ
    topBtn.click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
});
</script>
</body>
</html>
