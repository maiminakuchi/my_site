<?php
session_start();

$_SESSION['name']=$_POST;
$_SESSION['kana']=$_POST;
$_SESSION['phone']=$_POST;
$_SESSION['mail']=$_POST;
$_SESSION['body']=$_POST;
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>お問い合わせ
  </title>
  <link rel="stylesheet" type="text/css" href="../css/contact.css">
</head>
<body>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>


<?php include("header.php"); ?>
<?php include("val.php"); ?>

<!-- ⭐️ -->

<section class="section2">
 <div class="contact-box">
   <h2 class="head">お問い合わせ</h2>
    <form method="post" action="confirm2.php" id="form1">
    <h3>下記の項目をご記入の上送信ボタンを押してください</h3>
    <p>送信頂いた件につきましては、当社より折り返しご連絡を差し上げます。</p>
    <p>なお、ご連絡までに、お時間を頂く場合もございますので予めご了承ください。</p>
    <p><span class="kome">*</span>は必須項目となります。</p>
    <dl>
      <dt><label for="name">氏名<span class="kome">*</span></label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if (count($err_msg)>0){
       echo $err_msg[
0
       ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd>
      <input type="text" name="name" id="name" placeholder="海野守" value="<?php if($_POST){echo $name;} ?>">
      </dd>

      <dt><label for="kana">フリガナ<span class="kome">*</span></label></dt>

      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if(count($err_msg)>0){
       echo $err_msg[
1
       ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="kana" id="kana" placeholder="ウミノマモル" value="<?php if($_POST){echo $kana;} ?>"></dd>

      <dt><label for="phone">電話番号</label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if(count($err_msg)>0){
       echo $err_msg[
2
       ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="phone" id="phone" placeholder="09012345678" value="<?php if($_POST){echo $phone;} ?>"></dd>

      <dt><label for="email">メールアドレス<span class="kome">*</span></label></dt>
      <!-- エラー表示 -->
      <dd class="err">
       <?php
       if(count($err_msg)>0){
       echo $err_msg[
3
       ];
       }
       ?>
      </dd>
      <!-- ここまで -->
      <dd><input type="text" name="email" id="email" placeholder="umino@test.co.jp" value="<?php if($_POST){echo $email;} ?>"></dd>
      <h3>お問い合わせ内容をご記入ください<span class="kome">*</span></h3>
        </dl>
        <dl>
          <!-- エラー表示 -->
          <dd class="err">
           <?php
           if(count($err_msg)>0){
           echo $err_msg[
4
           ];
           }
           ?>
          </dd>
          <!-- ここまで -->
          <dd><textarea name="body" id="body"><?php if($_POST){echo $body;} ?></textarea></dd>
          <dd><input class="submit" type="submit" value="送　信"></dd>
        </dl>

    </form>
 </div>

<!-- jqueryバリデーション -->
    <script>
      $('#submit1').click(function(){
        var name = $('#name').val(); //value()を使ってvalue値(value=""の部分)を取得
        var kana = $('#kana').val();
        var tel = $('#tel').val();
        var mail = $('#mail').val();
        var body = $('#body').val();
        var resurt = 0;
        //氏名チェック
        if (name == "" || name.length > 10) {
          resurt += 1;
        }
        // フリガナチェック
        if (kana == "" || kana.length > 10) {
          resurt += 1;

        }
        // 電話番号チェック
        if ( tel !== "" && !tel.match(/^[0-9]+$/)) {
          resurt += 1;
        }
        // メールアドレスチェック
        // 先頭の1文字/＠まで/＠/ドメインまで/ドメイン
        if (!mail.match(/^[A-Za-z0-9]{1}[A-Za-z0-9_.-]*@{1}[A-Za-z0-9_.-]{1,}\.[A-Za-z0-9]{1,}$/)) {
          resurt += 1;
        }
        //お問い合わせ内容チェック
        if (body == "") {
          resurt += 1;
        }
        // チェックに引っかかっていたら遷移しない
        if (resurt > 0){
          $('form').submit(function() {
          $(this).attr('action', 'contact.php');
          });
        }
        //ブラウザ側が標準で用意しているイベントを中断できる
        // if (resurt > 0){
        //   return false;
        // }
      });
    </script>





</section>



<!-- ⭐️ -->
<section class="hooter">
 <div class="outer">
  <div class="info">
   <div class="inner">
   	<h2>企業情報</h2>
   	 <ul>
      <li><a href="#">ご利用方法</a></li>
      <li><a href="#">ニュースルーム</a></li>
      <li><a href="#">株主・投資家のみなさまへ</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">採用情報</a></li>
     </ul>
    </div>
    <div class="inner">
      	<h2>コミュニティ</h2>
   	 <ul>
      <li><a href="#">ダイバーシティ</a></li>
      <li><a href="#">アクセシビリティ対応</a></li>
      <li><a href="#">お友達を招待</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>ホスト</h2>
   	 <ul>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>サポート</h2>
   	 <ul>
      <li><a href="#">新型コロナウイルスに対する取り組み</a></li>
      <li><a href="#">ヘルプセンター</a></li>
      <li><a href="#">キャンセルオプション</a></li>
      <li><a href="#">コミュニティサポート</a></li>
      <li><a href="#">信頼＆安全</a></li>
     </ul>
   </div>
  </div>
  <div class="policy">
  	<p>このサイトの素材は全て著作権フリーのものを使用しています。</p>
  	<div class="hooterlink">
  	 <a href="">プライバシーポリシー  </a>
  	 <a href="">利用規約  </a>
  	 <a href="">サイトマップ  </a>
  	 <a href="">企業情報  </a>
  	</div>
  	<div class="copy">© 2021- LiNew, Inc. All rights reserved.</div>
  </div>
 </div>
</section>


<p id="page-top"><a href="#wrap">Jump To Top</a></p>
<script>
$(function() {
    var showFlag = false;
    var topBtn = $('#page-top');
    topBtn.css('bottom', '-100px');
    var showFlag = false;
    //スクロールが100に達したらボタン表示
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            if (showFlag == false) {
                showFlag = true;
                topBtn.stop().animate({'bottom' : '0px'}, 200);
            }
        } else {
            if (showFlag) {
                showFlag = false;
                topBtn.stop().animate({'bottom' : '-100px'}, 200);
            }
        }
    });
    //スクロールしてトップ
    topBtn.click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
});
</script>
</body>
</html>
