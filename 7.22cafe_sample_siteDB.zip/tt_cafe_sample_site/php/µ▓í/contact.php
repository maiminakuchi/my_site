<!--  <a href="index2.php">
        お問い合わせ</a></div>

position
スクロールイベント　ヘッダー。トップに戻る
display none
popup js fade in
 -->



<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>お問い合わせ
  </title>
  <link rel="stylesheet" type="text/css" href="../css/contact.css">
</head>
<body>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
   <script>
    $(function(){
    $('.hajimeni').click(function() {
    var position = $(".location").offset().top;
    $('body,html').animate({scrollTop:position}, 500, 'swing');
    return false;
    });
    });


    $(function(){
    $('.taiken').click(function() {
    var position = $(".black").offset().top;
    $('body,html').animate({scrollTop:position}, 1000, 'swing');
    return false;
    });
    });




    $(function(){
    $('.signin2').on("click",function() {
    $('.overlay').css({
        'display'         :'block',
    	'opacity'         :'1',
    	'margin-top'      :'0px',
    	'transition'      :'all 1s ease',
    	'transition-delay': '0s',
        });
    $('.bg-black').css({
    	'background-color': 'rgba(0, 0, 0, 0.5)',
        'opacity'         :'1',
    	  'width'         : '100%',
        'height'        : '100%',
        'z-index'       : '10',
        'top'           : '0',
        'left'          : '0',
        'position'      : 'fixed'
    });
    });
    });

    $(document).on('click',function(e) {
   if(!$(e.target).closest('.signin2').length &&
    !$(e.target).closest('.overlay').length) {
     // ターゲット要素の外側をクリックした時の操作サインインの箱の中身以外、かつ、ポップアップウィンドウの箱の外側

    $('.overlay').animate({'opacity':0}, 0);
    $('.bg-black').animate({'opacity':0}, 0);
    $('.bg-black').css({'z-index':-1});
// pos:unsetでもいい
   } 
});






    // $('.bg-black').on('click touchend', function(event) {
    // // 表示したポップアップ以外の部分をクリックしたとき
    // if (!$(event.target).closest('.signin2').length) {
    // // $('.overlay').animate({'opacity':0},1000);
    // // $('.bg-black').animate({'opacity':0},1000);
    // }

    // });


  //   jQuery( window ).on( 'scroll', function(){

  //   if ( 65 < jQuery( this ).scrollTop() ) {
  //   jQuery( '#nav__top' ).addClass( '.header2' );
  //   }
  //   else{
  //   jQuery( '#nav__top' ).removeClass( '.header2' );
  //   }
  //   });

  //   $(function(){
  //   $('a[href^="#"]').click(function(){
  //     let speed = 500;
  //     let href= $(this).attr("href");
  //     let target = $(href == "#" || href == "" ? 'html' : href);
  //     let position = target.offset().top;
  //     $("html, body").animate({scrollTop:position}, speed, "swing");
  //     return false;
  //   });
  // });








// //スクロールすると上部に固定させるための設定を関数でまとめる
// function FixedAnime() {
//   var headerH = $('.alart').outerHeight(true);
//   var value = $(this).scrollTop();

//   if (value >= headerH){//headerの高さ以上になったら
//       $('.header').addClass('.header2');//fixedというクラス名を付与
//     }else{//それ以外は
//       $('.header').removeClass('.header2');//fixedというクラス名を除去
//     }
// }

// //ナビゲーションをクリックした際のスムーススクロール
// $('#g-navi a').click(function () {
//   var elmHash = $(this).attr('href'); //hrefの内容を取得
//   var pos = Math.round($(elmHash).offset().top-120);  //headerの高さを引く
//   $('body,html').animate({scrollTop: pos}, 500);//取得した位置にスクロール※数値が大きいほどゆっくりスクロール
//   return false;//リンクの無効化
// });

   </script>


<!-- ⭐️ -->

     <nav class="header">
       <div class="logo">
        <a href="index1.php">
          <img src="../img/logo.png" alt="Cafe">
        </a>
      </div>
      <div class="center">
        <div class="hajimeni">
        <a href="index1.php">
        はじめに</a></div>
        <div class="taiken">
        <a href="index1.php">
        体験</a></div>
        <div class="otoi">
        <a href="contact.php">
        お問い合わせ</a></div>
      </div>
      <div class="signin">
        <div class="signin2">
        <p>サインイン</p>
        </div>
      </div>
     </nav>





<!-- 🍎ログイン🍎 -->
<div class="bg-black">
     <div class="overlay">
     <div class="login">ログイン</div>
     <div class="up">
       <input type="text" name="e-mail" placeholder="メールアドレス">
       <input type="text" name="password" placeholder="パスワード">
       <button type='submit' class="submit">送信</button>
     </div>
     <dl class="down">
       <dd><button><img src="../img/twitter.png"></button></dd>
       <dd><button><img src="../img/fb.png"></button></dd>
       <dd><button><img src="../img/google.png"></button></dd>
       <dd><button><img src="../img/apple.png"></button></dd>
     </dl>
     </div>
</div>
<!-- 🍎ログイン🍎 -->

<!-- ⭐️ -->
<section class="section2">

     <div class="contact-box">
     <h2 class="head">お問い合わせ</h2>
      <form method="post" action="comfirm2.php">
        <h3>下記の項目をご記入の上送信ボタンを押してください</h3>
        <p>送信頂いた件につきましては、当社より折り返しご連絡を差し上げます。</p>
        <p>なお、ご連絡までに、お時間を頂く場合もございますので予めご了承ください。</p>
        <p><span class="kome">*</span>は必須項目となります。</p>
        <dl>
          <dt><label for="name">氏名<span class="kome">*</span></label></dt>
          <dd><input type="text" name="name" id="name" placeholder="海野守"></dd>

          <dt><label for="kana">フリガナ<span class="kome">*</span></label></dt>
          <dd><input type="text" name="kana" id="kana" placeholder="ウミノマモル"></dd>

          <dt><label for="phone">電話番号</label></dt>
          <dd><input type="text" name="phone" id="phone" placeholder="09012345678"></dd>

          <dt><label for="kana">メールアドレス<span class="kome">*</span></label></dt>
          <dd><input type="text" name="email" id="email" placeholder="umino@test.co.jp"></dd>
          <h3>お問い合わせ内容をご記入ください<span class="kome">*</span></h3>
        </dl>
        <dl>
          <dd><textarea name="body" id="body"></textarea></dd>
          <dd><input class="submit" type="submit" value="送信"></dd>
        </dl>

     </form>
     </div>

</section>



<!-- ⭐️ -->
<section class="hooter">
 <div class="outer">
  <div class="info">
   <div class="inner">
   	<h2>企業情報</h2>
   	 <ul>
      <li><a href="#">ご利用方法</a></li>
      <li><a href="#">ニュースルーム</a></li>
      <li><a href="#">株主・投資家のみなさまへ</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">採用情報</a></li>
     </ul>
    </div>
    <div class="inner">
      	<h2>コミュニティ</h2>
   	 <ul>
      <li><a href="#">ダイバーシティ</a></li>
      <li><a href="#">アクセシビリティ対応</a></li>
      <li><a href="#">お友達を招待</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>ホスト</h2>
   	 <ul>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
      <li><a href="#">XXXXXXXXXXXXXXX</a></li>
     </ul>
     </div>
     <div class="inner">
      	<h2>サポート</h2>
   	 <ul>
      <li><a href="#">新型コロナウイルスに対する取り組み</a></li>
      <li><a href="#">ヘルプセンター</a></li>
      <li><a href="#">キャンセルオプション</a></li>
      <li><a href="#">コミュニティサポート</a></li>
      <li><a href="#">信頼＆安全</a></li>
     </ul>
   </div>
  </div>
  <div class="policy">
  	<p>このサイトの素材は全て著作権フリーのものを使用しています。</p>
  	<div class="hooterlink">
  	 <a href="">プライバシーポリシー  </a>
  	 <a href="">利用規約  </a>
  	 <a href="">サイトマップ  </a>
  	 <a href="">企業情報  </a>
  	</div>
  	<div class="copy">© 2021- LiNew, Inc. All rights reserved.</div>
  </div>
 </div>
</section>


<p id="page-top"><a href="#wrap">Jump To Top</a></p>
<script>
$(function() {
    var showFlag = false;
    var topBtn = $('#page-top');
    topBtn.css('bottom', '-100px');
    var showFlag = false;
    //スクロールが100に達したらボタン表示
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            if (showFlag == false) {
                showFlag = true;
                topBtn.stop().animate({'bottom' : '0px'}, 200);
            }
        } else {
            if (showFlag) {
                showFlag = false;
                topBtn.stop().animate({'bottom' : '-100px'}, 200);
            }
        }
    });
    //スクロールしてトップ
    topBtn.click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 500);
        return false;
    });
});
</script>
</body>
</html>
